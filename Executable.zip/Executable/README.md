# README

Windows executable for the character controller test scene.
Controls:

AWSD to move around
Spacebar to jump
K to dash

Implemented: the previous, together with a wall jump similar to Hollow Knight's.